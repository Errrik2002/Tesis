library(deSolve)


#Parametros
alpha1 <- 5.8*10**-8 #1
alpha2 <- 2.5*10**-9 #2
#mu1 <- 0.06 # REFERENCIA DE YANG 2015 (HAY OTRO VALOR)
mu1 <- 0.06 #3
nu1 <- 0.99 # REFERENCIA DE FREITAS, LA OTRA OPCION ES MUY DRASTICA  #4 
mu2 <- 5*10**-1 #5
mu3 <- 0 #MISMO VALOR QUE EL DE LOS MACROFAGOS, MU2 #6
mu4 <- 6.5*10**-4 #ES LA SUMA DE PARAMETRO DE MUERTE DEL PARASITO Y SU ELIMINACION POR CD8 #7
alpha3 <- 0 #replicacion Mi #8
alpha4 <- 90 #Replicacion Ci #9
mu5 <- 9*10**-1 #10
mu6 <- 1*10**-6 #11
alpha5 <- 14.4 #12
alpha7 <- 0.45 #SECRECION DE IL10 #13
mu7 <- 24 #TASA DE degradacion DE TNF #en base a la literatura CADA 18 MIN #14
mu9 <- 19.2 #15 Degradacion de IL10
n1 <- 17.4 #TNF-IL10
n2 <- 560 #IL10-IL6
h1 <- 3 #TNF-IL10
h2 <- 3.68 #IL10-IL6
M0 <-209 # NUMERO EQUIS
qTNF <- 0.14 #16
qIL10 <- 0.15 #17  
n3 <- 100 #MTNF
h3 <- 3.16 #MTNF
n4 <- 4.35 #MIL10
h4 <- 0.3#MIL10


    
#    return(list(c(d_TL,d_M,d_Cn,d_Mi,d_Ci,d_TNF,d_IL10)))


trypanosoma_29_NOV <- function(t,state,parameter){
  with(as.list(c(state,parameter)),  {
    d_TL <- (alpha1*((TNF**h3)/((n3**h3)+TNF**h3))*(n4**h4)/((n4**h4)+IL10**h4))*TL*M-alpha2*TL*Cn+(mu1*((TNF**h3)/((n3**h3)+TNF**h3))*((n4**h4)/((n4**h4)+IL10**h4)))*TL+(alpha3*((TNF**h3)/((n3**h3)+TNF**h3))*((n4**h4)/((n4**h4)+IL10**h4)))*Mi+alpha4*Ci
    d_M <- (nu1*((TNF**h1)/((n3**h3)+TNF**h3))*((n4**h4)/((n4**h4)+IL10**h4)))*(M0-M)+(alpha1*((TNF**h3)/((n3**h3)+TNF**h3))*(n4**h4)/((n4**h4)+IL10**h4))*TL*M+(mu2*((TNF**h3)/((n3**h3)+TNF**h3))*((n4**h4)/((n4**h4)+IL10**h4)))*M
    d_Cn <- -alpha2*TL*Cn+(mu3*((TNF**h3)/((n3**h3)+TNF**h3))*((n4**h4)/((n4**h4)+IL10**h4)))*Cn
    d_Mi <- (alpha1*((TNF**h3)/((n3**h3)+TNF**h3))*(n4**h4)/((n4**h4)+IL10**h4))*TL*M+(mu5*((TNF**h3)/((n3**h3)+TNF**h3))*((n4**h4)/((n4**h4)+IL10**h4)))*Mi
    d_Ci <- alpha2*TL*Cn+(mu6*((TNF**h3)/((n3**h3)+TNF**h3))*((n4**h4)/((n4**h4)+IL10**h4)))*Ci
    d_TNF <- (alpha5*((n1**h1)/((n1**h1)+IL10**h1)))*Mi-mu7*(TNF-qTNF)+(alpha5*((n1**h1)/((n1**h1)+IL10**h1)))*Ci
    d_IL10 <- alpha7*Mi - mu9*(IL10-qIL10)

    return(list(c(d_TL,d_M,d_Cn,d_Mi,d_Ci,d_TNF,d_IL10)))      
  })
}


parameter <- c(alpha1,alpha2, mu1, nu1, mu2, mu3, mu4, alpha3, alpha4, mu5, mu6, alpha5, alpha7, mu7, mu9, n1, n2, h1, h2, qIL10, qTNF,M0) 
state <- c(TL=50, M=209, Cn= 136, Mi= 0, Ci = 0, TNF = 0.14, IL10 =0.15)
times <- seq(0,3650, by=1)
out29_NOV <- ode(y= state, times = times, func= trypanosoma_29_NOV, parms = parameter)

plot(out29_NOV,col='red')


png("images/10_DIC_2024_macrofagos_M1.png")
plot(out29_NOV,col='red')
dev.off()


############################## SIN FUNCIONES DE HILL ###################

trypanosoma_02_DIC <- function(t, state, parameter){
  with(as.list(c(state,parameter)), {
    dec_TL <- alpha1*TL*M-alpha2*TL*Cn+mu1*TL+alpha3*Mi+alpha4*Ci
    dec_M <- nu1*(M-M0)+alpha1*TL*M+mu2*M
    dec_Cn <- -alpha2*TL*Cn+mu3*Cn
    dec_Mi <- alpha1*TL*M+mu5*Mi
    dec_Ci <- alpha2*TL*Cn+mu6*Ci
    dec_TNF <- alpha5*Mi-mu7*TNF
    dec_IL10 <- alpha7-mu9*IL10
    
    
    return(list(c(dec_TL,dec_M,dec_Cn,dec_Mi,dec_Ci,dec_TNF,dec_IL10)))
  })
}
  
out_02_DEC_No_Hill <- ode(y=state, times=times,func = trypanosoma_02_DIC,parms = parameter)

plot(out_02_DEC_No_Hill, col='red')  

##################### No se ve chido




  
  
  
  
  
  
  
  
  
