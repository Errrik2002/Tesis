library(deSolve)

##################### ECUACIONES DE TESIS ###############


#Parametros
#alpha1 <- 3.14*10**-10
#alpha2 <- 2.5*10**-9
#mu1 <- 0.06 # REFERENCIA DE YANG 2015 (HAY OTRO VALOR)
#mu1 <- 0.06
#nu2 <- 1 # REFERENCIA DE FREITAS, LA OTRA OPCION ES MUY DRASTICA 
#mu2 <- 5*10**-1
#mu3 <- 1*10**-7 #MISMO VALOR QUE EL DE LOS MACROFAGOS, MU2
#mu4 <- 6.5*10**-4 #ES LA SUMA DE PARAMETRO DE MUERTE DEL PARASITO Y SU ELIMINACION POR CD8
#alpha3 <- 90 #replicacion Ci
#alpha4 <- 90 #Replicacion Mi
#mu5 <- 9*10**-1
#mu6 <- 1*10**-6
#alpha5 <- 200
#alpha6 <- 41.44 #TASA DE SECRECION DE IFN #la pendiente del experimento
#alpha7 <- 1.1 #SECRECION DE IL10
#mu7 <- 72 #TASA DE degradacion DE TNF #en base a la literatura CADA 18 MIN
#mu8 <- 0.74 #NO TIENEN TASA DE DEGRADACION IFN g 
#mu9 <- 0.74 #NO TIENEN TASA DE DEGRADACION IL10
#n1 <- 17.4 #TNF-IL10
#n2 <- 560 #IL10-IL6
#h1 <- 3 #TNF-IL10
#h2 <- 3.68 #IL10-IL6
#M0 <-50 # NUMERO EQUIS
#qTNF <- 0.14
#qIFN <- 0.10
#qIL10 <- 0.15




#####ECUACIONES####
trypanosoma <- function(t, state, parameter){
  with(as.list(c(state, parameter)), {
  d_TL <- -alpha1*((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(M)*(IFN)+IFN**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))*TL*M-alpha2*TL*Cn-(mu1*((TNF**h1)/((n1**h1)*(TL)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(TL)*(IFN)+IFN**h1))*(((n2**h2)*(TL)*(IL10))/((n2**h2)*(TL)*(IL10)+IL10**h2)))*TL
  d_M <- (nu2*((TNF**h1)/((n1**h1)*(TL)*(TNF)+TNF**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2)))*(M-M0)-(alpha1*(((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(IFN)+(IFN**h1)))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))))*TL*M-(mu2*(((IFN**h1)/((n1**h1)*(M)*(IFN)+IFN**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))))*M
  d_Cn <- -alpha2*TL*Cn-(mu3*(((IFN**h1)/((n1**h1)*(Cn)*(IFN)+IFN**h1))*(((n2**h2)*(Cn)*(IL10))/((n2**h2)*(Cn)*(IL10)+IL10**h2))))*Cn
  d_Ti <- alpha2*TL*Cn+(alpha1*((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(M)*(IFN)+IFN**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2)))*TL*M-(mu4*((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(M)*(IFN)+IFN**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2)))*Ti+((((TNF**h1)/((n1**h1)*(Ti)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(Ti)*(IFN)+IFN**h1))*(((n2**h2)*(Ti)*(IL10))/((n2**h2)*(Ti)*(IL10)+IL10**h2)))*(alpha3+alpha4))*Ti
  d_Mi <- (alpha1*((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(M)*(IFN)+IFN**h1))*(((n2**h2)*(M)*(IL10))/(n2**h2*(M)*(IL10)+IL10**h2)))*TL*M-(mu5*(((IFN**h1)/((n1**h1)*(M)*(IFN)+IFN**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))))*Mi
  d_Ci <- alpha2*TL*Cn-(mu6*((TNF**h1)/((n1**h1)*(Ci)*(TNF)+TNF**h1))*((IFN**h1)/((n1**h1)*(Ci)*(IFN)+IFN**h1))*(((n2**h2)*(Ci)*(IL10))/((n2**h2)*(Ci)*(IL10)+IL10**h2)))*Ci
  d_TNF <- (alpha5*(((n1**h1)*(TNF)*(IL10))/((n1**h1)*(TNF)*(IL10)+IL10**h1)))*Mi-mu7*(TNF-qTNF)
  d_IFN <- (alpha5*(((n1**h1)*(IFN)*(IL10))/((n1**h1)*(IFN)*(IL10)+IL10**h1)))*Ci-mu8*(IFN-qIFN)
  d_IL10 <- alpha7-mu9*(IL10-qIL10)
  
  return(list(c(d_TL,d_M,d_Cn,d_Ti,d_Mi,d_Ci,d_TNF,d_IFN,d_IL10)))
  })
}


parameter <- c(alpha1,alpha2, mu1, nu2, mu2, mu3, mu4, alpha3, alpha4, mu5, mu6, alpha5, alpha6, alpha7, mu7, mu8, mu9, n1, n2, h1, h2, qIL10, qIFN, qTNF,M0) 
state <- c(TL= 50, M=209, Cn= 136, Ti=0, Mi= 0, Ci = 0, TNF = 0.14, IFN = 0.1, IL10 =0.15)
times <- seq(0,3650, by=1)
out <- ode(y= state, times = times, func= trypanosoma, parms = parameter)


plot(out)


pdf("images/16_OCT_2024.pdf")
plot(out,col='red')
dev.off()
#Curvas solucion proxima semana deSolve
#Revisarlas con lupa
#escribir ecuaciones con descriptores











##### NUEVAS ECUACIONES SIN TI ####
#########################################################################################################
library(deSolve)

#Parametros
alpha1 <- 3.14*10**-10 #1
alpha2 <- 2.5*10**-9 #2
#mu1 <- 0.06 # REFERENCIA DE YANG 2015 (HAY OTRO VALOR)
mu1 <- 0.06 #3
nu2 <- 1 # REFERENCIA DE FREITAS, LA OTRA OPCION ES MUY DRASTICA  #4 
mu2 <- 5*10**-1 #5
mu3 <- 1*10**-7 #MISMO VALOR QUE EL DE LOS MACROFAGOS, MU2 #6
mu4 <- 6.5*10**-4 #ES LA SUMA DE PARAMETRO DE MUERTE DEL PARASITO Y SU ELIMINACION POR CD8 #7
alpha3 <- 30 #replicacion Mi #8
alpha4 <- 90 #Replicacion Ci #9
mu5 <- 9*10**-1 #10
mu6 <- 1*10**-6 #11
alpha5 <- 200 #12
alpha7 <- 0.19 #SECRECION DE IL10 #13
mu7 <- 72 #TASA DE degradacion DE TNF #en base a la literatura CADA 18 MIN #14
mu9 <- 1.1 #15
n1 <- 17.4 #TNF-IL10
n2 <- 560 #IL10-IL6
h1 <- 3 #TNF-IL10
h2 <- 3.68 #IL10-IL6
M0 <-50 # NUMERO EQUIS
qTNF <- 0.14 #16
qIL10 <- 0.15 #17  


trypanosoma_18OCT <- function(t, state, parameter){
  with(as.list(c(state, parameter)), {
    d_TL <- -alpha1*((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))*TL*M-alpha2*TL*Cn-(mu1*((TNF**h1)/((n1**h1)*(TL)*(TNF)+TNF**h1))*(((n2**h2)*(TL)*(IL10))/((n2**h2)*(TL)*(IL10)+IL10**h2)))*TL+(alpha3*((TNF**h1)/((n1**h1)*(TL)*(TNF)+TNF**h1))*(((n2**h2)*(TL)*(IL10))/((n2**h2)*(TL)*(IL10)+IL10**h2)))*Mi+alpha4*Ci
    d_M <- (nu2*((TNF**h1)/((n1**h1)*(TL)*(TNF)+TNF**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2)))*(M-M0)-(alpha1*(((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))))*TL*M-(mu2*(((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))))*M
    d_Cn <- -alpha2*TL*Cn-(mu3*(((TNF**h1)/((n1**h1)*(Cn)*(TNF)+TNF**h1))*(((n2**h2)*(Cn)*(IL10))/((n2**h2)*(Cn)*(IL10)+IL10**h2))))*Cn
    d_Mi <- (alpha1*((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*(((n2**h2)*(M)*(IL10))/(n2**h2*(M)*(IL10)+IL10**h2)))*TL*M-(mu5*(((TNF**h1)/((n1**h1)*(M)*(TNF)+TNF**h1))*(((n2**h2)*(M)*(IL10))/((n2**h2)*(M)*(IL10)+IL10**h2))))*Mi
    d_Ci <- alpha2*TL*Cn-(mu6*((TNF**h1)/((n1**h1)*(Ci)*(TNF)+TNF**h1))*(((n2**h2)*(Ci)*(IL10))/((n2**h2)*(Ci)*(IL10)+IL10**h2)))*Ci
    d_TNF <- (alpha5*(((n1**h1)*(TNF)*(IL10))/((n1**h1)*(TNF)*(IL10)+IL10**h1)))*Mi-mu7*(TNF-qTNF)
    d_IL10 <- alpha7*Mi-mu9*(IL10-qIL10)
    
    return(list(c(d_TL,d_M,d_Cn,d_Mi,d_Ci,d_TNF,d_IL10)))
  })
}


parameter <- c(alpha1,alpha2, mu1, nu2, mu2, mu3, mu4, alpha3, alpha4, mu5, mu6, alpha5, alpha6, alpha7, mu7, mu8, mu9, n1, n2, h1, h2, qIL10, qIFN, qTNF,M0) 
state <- c(TL=50, M=209, Cn= 136, Mi= 0, Ci = 0, TNF = 0.14, IL10 =0.15)
times <- seq(0,100, by=1)
out <- ode(y= state, times = times, func= trypanosoma_18OCT, parms = parameter)

plot(out,col='red')


pdf("images/21_OCT_2024_100D.pdf")
plot(out,col='red')
dev.off()

#### sensibilidad parametrica ####

#install.packages("pksensi")
library(pksensi)

#install.packages("remotes")
#remotes::install_github("nanhung/pksensi")

#mcsim_install() no se instala, a lo mejor es por el Rtools44

#install.packages("httk")
library(httk)

#Opcional
#pars1comp <- (parameterize_1comp(chem.name = "acetaminophen"))

q <- c("qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif","qunif")
q.arg <- list(list(min= alpha1/2, max= alpha1*2), #1
              list(min= alpha2/2, max= alpha2*2), #2
              list(min= mu1/2, max= mu1*2),#3
              list(min= nu2/2, max= nu2*2),#4
              list(min= mu2/2, max= mu2*2),#5
              list(min= mu3/2, max= mu3*2),#6
              list(min= mu4/2, max= mu4*2),#7
              list(min= alpha3/2, max= alpha3*2),#8
              list(min= alpha4/2, max= alpha4*2),#9
              list(min= mu5/2, max= mu5*2),#10
              list(min= mu6/2, max= mu6*2),#11
              list(min= alpha5/2, max= alpha5*2),#12
              list(min= alpha7/2, max= alpha7*2),#13
              list(min= mu7/2, max= mu7*2),#14
              list(min= mu9/2, max= mu9*2),#15
              list(min= qTNF/2, max= qTNF*2),#16
              list(min= qIL10/2, max = qIL10*2))#17


#create parameter Matrix

set.seed(1234)

param_ASP <- c("alpha1","alpha2", "mu1", "nu2", "mu2", "mu3", "mu4", "alpha3", "alpha4", "mu5", "mu6", "alpha5", "alpha7", "mu7", "mu9", "qIL10", "qTNF") 

ASP <- rfast99(param_ASP, n=200, q=q, q.arg = q.arg, replicate = 1)

out_ASP <- solve_fun(ASP, time = times, func = trypanosoma_18OCT, initState = state, outnames = out)


#----------#######################3---------------------------------------------------


library(deSolve)

#Parametros
alpha1 <- 3.14*10**-10 #1
alpha2 <- 2.5*10**-9 #2
#mu1 <- 0.06 # REFERENCIA DE YANG 2015 (HAY OTRO VALOR)
mu1 <- 0.06 #3
nu2 <- 1 # REFERENCIA DE FREITAS, LA OTRA OPCION ES MUY DRASTICA  #4 
mu2 <- 5*10**-1 #5
mu3 <- 1*10**-7 #MISMO VALOR QUE EL DE LOS MACROFAGOS, MU2 #6
mu4 <- 6.5*10**-4 #ES LA SUMA DE PARAMETRO DE MUERTE DEL PARASITO Y SU ELIMINACION POR CD8 #7
alpha3 <- 30 #replicacion Mi #8
alpha4 <- 90 #Replicacion Ci #9
mu5 <- 9*10**-1 #10
mu6 <- 1*10**-6 #11
alpha5 <- 200 #12
alpha7 <- 0.19 #SECRECION DE IL10 #13
mu7 <- 72 #TASA DE degradacion DE TNF #en base a la literatura CADA 18 MIN #14
mu9 <- 1.1 #15
n1 <- 17.4 #TNF-IL10
n2 <- 560 #IL10-IL6
h1 <- 3 #TNF-IL10
h2 <- 3.68 #IL10-IL6
M0 <-50 # NUMERO EQUIS
qTNF <- 0.14 #16
qIL10 <- 0.15 #17  

trypanosoma_27NOV <- function(t, state, parameter){
  with(as.list(c(state, parameter)), {
    d_TL <- alpha1*((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2))*TL*M-alpha2*TL*Cn+(mu1*((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2)))*TL+(alpha3*((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2)))*Mi+alpha4*Ci
    d_M <- (nu2*((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2)))*(M-M0)+(alpha1*(((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2))))*TL*M+(mu2*(((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2))))*M
    d_Cn <- -alpha2*TL*Cn+(mu3*(((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2))))*Cn
    d_Mi <- (alpha1*((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2)))*TL*M+(mu5*(((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2))))*Mi
    d_Ci <- alpha2*TL*Cn+(mu6*((TNF**h1)/((n1**h1)+TNF**h1))*(((n2**h2))/((n2**h2)+IL10**h2)))*Ci
    d_TNF <- (alpha5*(((n1**h1))/((n1**h1)+IL10**h1)))*Mi-mu7*(TNF-qTNF)
    d_IL10 <- alpha7*Mi-mu9*(IL10-qIL10)
    
    return(list(c(d_TL,d_M,d_Cn,d_Mi,d_Ci,d_TNF,d_IL10)))
  })
}


parameter <- c(alpha1,alpha2, mu1, nu2, mu2, mu3, mu4, alpha3, alpha4, mu5, mu6, alpha5, alpha7, mu7, mu9, n1, n2, h1, h2, qIL10, qTNF,M0) 
state <- c(TL=50, M=209, Cn= 136, Mi= 0, Ci = 0, TNF = 0.14, IL10 =0.15)
times <- seq(0,100, by=1)
out1 <- ode(y= state, times = times, func= trypanosoma_27NOV, parms = parameter)

plot(out1,col='red')


pdf("images/29_NOV_2024_NOSIGNS_100D.pdf")
plot(out1,col='red')
dev.off()
